Projeto VntCHAT - server

Para rodar o projeto:
    - npm install (instala as dependencias)
    - node mongodb-example.js (para começar a aplicação)

Se quiser usar o [nodemon](https://nodemon.io/):
    - npm install nodemon -g (instala globalmente)
    - nodemon mongodb-example.js

Pre-requisito:
    - ter o node.js e o mongoDB instalados no ambiente
